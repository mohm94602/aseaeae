## Packages
framer-motion | For smooth animations of the result card and loading states
lucide-react | For platform icons and UI elements (already in base, but emphasizing use)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
